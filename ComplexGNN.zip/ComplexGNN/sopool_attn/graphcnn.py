import torch
import torch.nn as nn
import torch.nn.functional as F

from layers import GraphConvolution, GraphAttentionLayer
import numpy as np

import sys
sys.path.append("models/")
from mlp import MLP

from torch.autograd import Variable
import pdb

class GraphCNN(nn.Module):
    def __init__(self, num_layers, num_mlp_layers, input_dim, hidden_dim, output_dim, final_dropout, learn_eps, graph_pooling_type, neighbor_pooling_type, device):
        '''
            num_layers: number of layers in the neural networks (INCLUDING the input layer)
            num_mlp_layers: number of layers in mlps (EXCLUDING the input layer)
            input_dim: dimensionality of input features
            hidden_dim: dimensionality of hidden units at ALL layers
            output_dim: number of classes for prediction
            final_dropout: dropout ratio on the final linear layer
            learn_eps: If True, learn epsilon to distinguish center nodes from neighboring nodes. If False, aggregate neighbors and center nodes altogether. 
            neighbor_pooling_type: how to aggregate neighbors (mean, average, or max)
            graph_pooling_type: how to aggregate entire nodes in a graph (mean, average)
            device: which device to use
        '''

        super(GraphCNN, self).__init__()

        self.final_dropout = final_dropout
        self.device = device
        self.num_layers = num_layers
        self.graph_pooling_type = graph_pooling_type
        self.neighbor_pooling_type = neighbor_pooling_type
        self.learn_eps = learn_eps
        self.eps = nn.Parameter(torch.zeros(self.num_layers-1))

        self.alpha = 0.9

        ###List of MLPs
        self.mlps = torch.nn.ModuleList()

        ###List of batchnorms applied to the output of MLP (input of the final prediction linear layer)
        self.batch_norms = torch.nn.ModuleList()

        for layer in range(self.num_layers-1):
            if layer == 0:
                self.mlps.append(MLP(num_mlp_layers, input_dim, hidden_dim, hidden_dim))
            else:
                self.mlps.append(MLP(num_mlp_layers, hidden_dim, hidden_dim, hidden_dim))

            self.batch_norms.append(nn.BatchNorm1d(hidden_dim))

        # for attentional second-order pooling
        self.total_latent_dim = input_dim + hidden_dim * (num_layers - 1)

        # print("input_dim",input_dim,self.total_latent_dim)

        self.dense_dim = self.total_latent_dim
        self.attend = nn.Linear(self.total_latent_dim, 1)
        self.linear1 = nn.Linear(self.dense_dim, output_dim)
        self.output_dim = output_dim

        # GCN 
        self.gcn1=GraphConvolution(input_dim, self.total_latent_dim//3)
        self.gcn2=GraphConvolution(self.total_latent_dim//3, self.total_latent_dim)
        # GAT     
        # self.gcn1=GraphAttentionLayer(input_dim, self.total_latent_dim//4)
        # self.gcn2=GraphAttentionLayer(self.total_latent_dim//4, self.total_latent_dim)
   

        # self.gcn3=GraphConvolution(self.total_latent_dim//2, self.total_latent_dim)
        
        self.fc = nn.Linear(self.total_latent_dim,self.output_dim,bias=False)

        self.LL=nn.ModuleList()

        for i in range(self.output_dim):
          self.LL.append(nn.Linear(self.total_latent_dim**2,1,bias=False))

    def __preprocess_neighbors_maxpool(self, batch_graph):
        ###create padded_neighbor_list in concatenated graph

        #compute the maximum number of neighbors within the graphs in the current minibatch
        max_deg = max([graph.max_neighbor for graph in batch_graph])

        padded_neighbor_list = []
        start_idx = [0]


        for i, graph in enumerate(batch_graph):
            start_idx.append(start_idx[i] + len(graph.g))
            padded_neighbors = []
            for j in range(len(graph.neighbors)):
                #add off-set values to the neighbor indices
                pad = [n + start_idx[i] for n in graph.neighbors[j]]
                #padding, dummy data is assumed to be stored in -1
                pad.extend([-1]*(max_deg - len(pad)))

                #Add center nodes in the maxpooling if learn_eps is False, i.e., aggregate center nodes and neighbor nodes altogether.
                if not self.learn_eps:
                    pad.append(j + start_idx[i])

                padded_neighbors.append(pad)
            padded_neighbor_list.extend(padded_neighbors)

        return torch.LongTensor(padded_neighbor_list)


    def __preprocess_neighbors_sumavepool(self, batch_graph):
        ###create block diagonal sparse matrix

        edge_mat_list = []
        start_idx = [0]
        for i, graph in enumerate(batch_graph):
            start_idx.append(start_idx[i] + len(graph.g))
            edge_mat_list.append(graph.edge_mat + start_idx[i])
        Adj_block_idx = torch.cat(edge_mat_list, 1)
        Adj_block_elem = torch.ones(Adj_block_idx.shape[1])

        #Add self-loops in the adjacency matrix if learn_eps is False, i.e., aggregate center nodes and neighbor nodes altogether.

        if not self.learn_eps:
            num_node = start_idx[-1]
            self_loop_edge = torch.LongTensor([range(num_node), range(num_node)])
            elem = torch.ones(num_node)
            Adj_block_idx = torch.cat([Adj_block_idx, self_loop_edge], 1)
            Adj_block_elem = torch.cat([Adj_block_elem, elem], 0)

        Adj_block = torch.sparse.FloatTensor(Adj_block_idx, Adj_block_elem, torch.Size([start_idx[-1],start_idx[-1]]))

        return Adj_block.to(self.device)


    def __preprocess_graphpool(self, batch_graph):
        ###create sum or average pooling sparse matrix over entire nodes in each graph (num graphs x num nodes)
        
        start_idx = [0]

        #compute the padded neighbor list
        for i, graph in enumerate(batch_graph):
            start_idx.append(start_idx[i] + len(graph.g))

        idx = []
        elem = []
        for i, graph in enumerate(batch_graph):
            ###average pooling
            if self.graph_pooling_type == "average":
                elem.extend([1./len(graph.g)]*len(graph.g))
            
            else:
            ###sum pooling
                elem.extend([1]*len(graph.g))

            idx.extend([[i, j] for j in range(start_idx[i], start_idx[i+1], 1)])
        elem = torch.FloatTensor(elem)
        idx = torch.LongTensor(idx).transpose(0,1)
        graph_pool = torch.sparse.FloatTensor(idx, elem, torch.Size([len(batch_graph), start_idx[-1]]))
        
        return graph_pool.to(self.device)

    def maxpool(self, h, padded_neighbor_list):
        ###Element-wise minimum will never affect max-pooling

        dummy = torch.min(h, dim = 0)[0]
        h_with_dummy = torch.cat([h, dummy.reshape((1, -1)).to(self.device)])
        pooled_rep = torch.max(h_with_dummy[padded_neighbor_list], dim = 1)[0]
        return pooled_rep


    def next_layer_eps(self, h, layer, padded_neighbor_list = None, Adj_block = None):
        ###pooling neighboring nodes and center nodes separately by epsilon reweighting. 

        if self.neighbor_pooling_type == "max":
            ##If max pooling
            pooled = self.maxpool(h, padded_neighbor_list)
        else:
            #If sum or average pooling
            pooled = torch.spmm(Adj_block, h)
            if self.neighbor_pooling_type == "average":
                #If average pooling
                degree = torch.spmm(Adj_block, torch.ones((Adj_block.shape[0], 1)).to(self.device))
                pooled = pooled/degree

        #Reweights the center node representation when aggregating it with its neighbors
        pooled = pooled + (1 + self.eps[layer])*h
        pooled_rep = self.mlps[layer](pooled)
        h = self.batch_norms[layer](pooled_rep)

        #non-linearity
        h = F.relu(h)
        return h


    def next_layer(self, h, layer, padded_neighbor_list = None, Adj_block = None):
        ###pooling neighboring nodes and center nodes altogether  
            
        if self.neighbor_pooling_type == "max":
            ##If max pooling
            pooled = self.maxpool(h, padded_neighbor_list)
        else:
            #If sum or average pooling
            pooled = torch.spmm(Adj_block, h)
            if self.neighbor_pooling_type == "average":
                #If average pooling
                degree = torch.spmm(Adj_block, torch.ones((Adj_block.shape[0], 1)).to(self.device))
                pooled = pooled/degree

        #representation of neighboring and center nodes 
        pooled_rep = self.mlps[layer](pooled)

        h = self.batch_norms[layer](pooled_rep)

        #non-linearity
        h = F.relu(h)
        return h


    def forward(self, batch_graph):
        X_concat = torch.cat([graph.node_features for graph in batch_graph], 0).to(self.device)

        # FFT
        X_concat = torch.fft.fft(X_concat)
        X_concat_real = X_concat.real
        X_concat_im = X_concat.imag

        # graph_pool = self.__preprocess_graphpool(batch_graph)

        if self.neighbor_pooling_type == "max":
            padded_neighbor_list = self.__preprocess_neighbors_maxpool(batch_graph)
        else:
            Adj_block = self.__preprocess_neighbors_sumavepool(batch_graph)

        #list of hidden representation at each layer (including input)

        hidden_rep = [X_concat_real]
        h = X_concat_real

        for layer in range(self.num_layers-1):
            if self.neighbor_pooling_type == "max" and self.learn_eps:
                h = self.next_layer_eps(h, layer, padded_neighbor_list = padded_neighbor_list)
            elif not self.neighbor_pooling_type == "max" and self.learn_eps:
                h = self.next_layer_eps(h, layer, Adj_block = Adj_block)
            elif self.neighbor_pooling_type == "max" and not self.learn_eps:
                h = self.next_layer(h, layer, padded_neighbor_list = padded_neighbor_list)
            elif not self.neighbor_pooling_type == "max" and not self.learn_eps:
                h = self.next_layer(h, layer, Adj_block = Adj_block)

            hidden_rep.append(h)

        hidden_rep = torch.cat(hidden_rep, 1)

        graph_sizes = [graph.node_features.size()[0] for graph in batch_graph]

        # batch_graphs = torch.zeros(len(graph_sizes), self.dense_dim).to(self.device)
        
        batch_graphs = torch.zeros(len(graph_sizes), self.output_dim).to(self.device)
        batch_graphs = Variable(batch_graphs)

        node_embeddings = torch.split(hidden_rep, graph_sizes, dim=0)

        # GCN(X_concat,Adj_block)  
        # Adjs = torch.split(Adj_block.to_dense(), graph_sizes, dim=1)   # 分解
        # X_= torch.split(X_concat, graph_sizes, dim=0)   # 分解

        # GCN embeddings
        x = F.relu(self.gcn1(X_concat_im,Adj_block))
        x = F.dropout(x, self.final_dropout, training=self.training)
        x = self.gcn2(x, Adj_block)        
        #x = F.relu(x)
        #x = F.dropout(x, self.final_dropout, training=self.training)
        #x = self.gcn3(x,Adj_block)
        g_emb= torch.split(x, graph_sizes, dim=0)  # embeddings for each graph in a batch
        ###############

        Sam1 = torch.zeros(self.output_dim)

        bias = Variable(torch.zeros(1),requires_grad=True)

        # beta = Variable(torch.zeros(1),requires_grad=True).cuda

        Weight = self.fc.weight
        Weight=torch.where(Weight>0,Weight,torch.zeros_like(Weight))
        # Weight = Variable(torch.ones_like(self.fc.weight),requires_grad=True).cuda()
        # Weight = torch.abs(Weight)


        for g_i in range(len(graph_sizes)):
            cur_node_embeddings = node_embeddings[g_i]
            gcn_emb = g_emb[g_i]
            # P_{MEAN} or P_{MAX}
            #  Sam0 = self.fc(torch.sum(cur_node_embeddings,dim=0,keepdim=True)+torch.sum(gcn_emb,dim=0,keepdim=True))
            # P_{Hadamard}
            #  Sam0 = self.fc(torch.sum(cur_node_embeddings,dim=0,keepdim=True)*torch.sum(gcn_emb,dim=0,keepdim=True))            
            # P_{MAX}
            # Sam0 = torch.max(cur_node_embeddings,0)[0]+torch.max(gcn_emb,0)[0]
            # Sam0 = self.fc(Sam0.unsqueeze(0))

            # print(torch.norm(cur_node_embeddings_,1))
 
            # cur_node_embeddings = torch.mm(torch.norm(cur_node_embeddings_,2,dim=1).diag(),cur_node_embeddings_)
            # gcn_emb = torch.mm(torch.norm(gcn_emb_,2,dim=1).diag(),gcn_emb_)
            
            W1 = torch.mm(cur_node_embeddings,cur_node_embeddings.t())+torch.mm(gcn_emb,gcn_emb.t())
            W2 = torch.mm(cur_node_embeddings,gcn_emb.t())-torch.mm(gcn_emb,cur_node_embeddings.t())
            W1_ = torch.cat((W1,-W2),dim=1)
            W2_ = torch.cat((W2,W1),dim=1)
            W = torch.cat((W1_,W2_),dim=0)
            
            _,sig,_ = torch.svd(W)
            sig = torch.Tensor([torch.sqrt(sig[i]) for i in range(0,len(sig),2)]) # take odd indices 
            sig=torch.cat([sig.cuda(),torch.zeros(self.total_latent_dim-sig.size(0)).cuda()],0).cuda()
            # Sam=self.fc(sig.pow(2).unsqueeze(0))
            Sam = torch.mm(sig.pow(2).unsqueeze(0),Weight.t())

            n_m = torch.mean(cur_node_embeddings,dim=0,keepdim=True) 
            g_m = torch.mean(gcn_emb,dim=0,keepdim=True)
            # Final = torch.mm(n_m.t(),g_m).flatten()
            # Sam1 = self.fc(n_m.unsqueeze(0))*self.fc(g_m.unsqueeze(0)) 
            #N = n_m+g_m
            # Sam1 = self.fc(N.unsqueeze(0))
            # Weight = self.fc.weight.pow(2)
            Sam1 = torch.mm(n_m,Weight.t())*torch.mm(g_m,Weight.t())

            # cur_adj = Adjs[g_i]
            # cur_input=X_[g_i]
            """
            attn_coef = self.attend(cur_node_embeddings)
            attn_weights = torch.transpose(attn_coef, 0, 1)
            cur_graph_embeddings = torch.matmul(attn_weights, cur_node_embeddings)
            print("尺寸1:{}".format(cur_graph_embeddings.size())) # 1 x 623
            batch_graphs[g_i] = cur_graph_embeddings.view(self.dense_dim)
            print("尺寸2:{}".format(batch_graphs[g_i].size()))
            """
            """          
            for i in range(self.output_dim):
                # LL = nn.Linear(self.total_latent_dim,1)
                AA = self.LL[i](cur_node_embeddings)                
                #print("AA_size:{}".format(AA.size()))
                # AA = AA.view(self.output_dim) 
                Sam[i]= torch.norm(AA,p=2).pow(2)
            batch_graphs[g_i]=Sam
            """
            """
            #for i in range(self.output_dim):
                #_,sig,_= torch.svd(cur_node_embeddings.t())
                #_,sig,_= torch.svd(gcn_emb.t())
                # print("=============size===================")
                # print(sig.size(0))
                # print(self.total_latent_dim,sig)
                
                # GCN
                # print(cur_input.size(),cur_adj.size()) 
                x = F.relu(self.gcn1(cur_input, cur_adj))
                # print("===========T======================")
                # print(cur_node_embeddings.size(),cur_adj.size())
                x = F.dropout(x, self.final_dropout, training=self.training)
                x = self.gcn2(x, cur_adj)
               
                # Complex_embedding = cur_node_embeddings.detach().cpu().numpy()+gcn_emb.detach().cpu().numpy()*1j
                # Complex_embedding = cur_node_embeddings.cpu().numpy()
                # _,sig,_=np.linalg.svd(Complex_embedding)
                # sig = torch.from_numpy(sig).cuda()
                
               
                # sig=torch.cat([sig,torch.zeros(self.total_latent_dim-sig.size(0)).cuda()],0)
                # print(cur_node_embeddings.size())
                # print(sig.pow(2).unsqueeze(1).size())
                #Sam[i]=self.LL[i](sig.pow(2).unsqueeze(0))
            #    Sam[i]=self.LL[i](Final)
            """
            #for i in range(self.output_dim):
            #    Sam1[i]=self.LL[i](Final)

            batch_graphs[g_i]=self.alpha*Sam+(1-self.alpha)*Sam1
            # batch_graphs[g_i]=Sam1          

        #  score = F.dropout(self.linear1(batch_graphs), self.final_dropout, training=self.training)
        batch_graphs=batch_graphs+bias.cuda()
        score = F.dropout(batch_graphs, self.final_dropout, training=self.training)
        #  score = batch_graphs  

        return score
